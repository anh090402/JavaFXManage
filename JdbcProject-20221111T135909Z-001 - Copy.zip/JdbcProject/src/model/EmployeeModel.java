/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import common.ICommon;
import dao.JDBCConnect;
import entity.Employee;
import entity.Student;
import java.sql.Connection;
import java.util.Date;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Hoang Anh
 */
public class EmployeeModel implements ICommon<Employee> {

    private Connection connection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet rs = null;

    @Override
    public ArrayList<Employee> getAll() {
        ArrayList<Employee> arrayList = new ArrayList<>();
        String sql = "SELECT * FROM tbl_exam";
        try {
            // kết nối được với db
            connection = JDBCConnect.getJDBCConnection();
            preparedStatement = connection.prepareStatement(sql);
            rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Employee employee = new Employee();
                employee.setId(rs.getInt("id"));
                employee.setExamName(rs.getString("exam_name"));
                employee.setExamDate(rs.getDate("exam_date"));
                employee.setExamDuration(rs.getInt("exam_duration"));
                employee.setExamRoom(rs.getString("exam_room"));

                arrayList.add(employee);
            }
            return arrayList;
        } catch (SQLException e) {
        } finally {
            JDBCConnect.closeResultSet(rs);
            JDBCConnect.closePreparedStatement(preparedStatement);
            JDBCConnect.closeConnection(connection);
        }
        return null;
    }

}
