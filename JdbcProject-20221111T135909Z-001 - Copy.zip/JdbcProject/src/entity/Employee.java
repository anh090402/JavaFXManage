/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.sql.Date;



/**
 *
 * @author Hoang Anh
 */
public class Employee {
    private int id;
    private String examName;
    private Date examDate;
    private int examDuration;
    private String examRoom;

    public Employee() {
    }

    public Employee(int id, String examName, Date examDate, int examDuration, String examRoom) {
        this.id = id;
        this.examName = examName;
        this.examDate = examDate;
        this.examDuration = examDuration;
        this.examRoom = examRoom;
    }
    
        public Employee(String examName, Date examDate, int examDuration, String examRoom) {
        this.id = id;
        this.examName = examName;
        this.examDate = examDate;
        this.examDuration = examDuration;
        this.examRoom = examRoom;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getExamName() {
        return examName;
    }

    public void setExamName(String exmName) {
        this.examName = exmName;
    }

    public Date getExamDate() {
        return examDate;
    }

    public void setExamDate(Date examDate) {
        this.examDate = examDate;
    }

    public int getExamDuration() {
        return examDuration;
    }

    public void setExamDuration(int examDuration) {
        this.examDuration = examDuration;
    }

    public String getExamRoom() {
        return examRoom;
    }

    public void setExamRoom(String examRoom) {
        this.examRoom = examRoom;
    }

    @Override
    public String toString() {
        return "Employee{" + "id=" + id + ", examName=" + examName + ", examDate=" + examDate + ", examDuration=" + examDuration + ", examRoom=" + examRoom + '}';
    }
    
    
}
