package config;

public interface IDBConfig {
    public static final String HOSTNAME ="localhost";
    public static final String PORT ="3306";
    public static final String DBNAME="demo_connect";
    public static final String INTEGRATED_SECURITY="false";
    public static final String USERNAME="root";
    public static final String PASSWORD="12345678";
}
